using System.Net.Http.Json;

var apiBaseUrl = "http://127.0.0.1:5000";
var printer = "Printer01";
var copies = 1;
var barcodeValue = "CS-001";
var barcodePrinter = "Printer02";
var barcodeCopies = 1;
var runLayoutTool = false;
var directPrintEnabled = true;
var barcodeDirectPrintEnabled = true;
var printTarget = "receipt";

foreach (var arg in args)
{
    if (arg.Equals("--layout-tool", StringComparison.OrdinalIgnoreCase)
        || arg.Equals("--web", StringComparison.OrdinalIgnoreCase))
    {
        runLayoutTool = true;
    }
    else if (arg.StartsWith("--printer=", StringComparison.OrdinalIgnoreCase))
    {
        printer = arg["--printer=".Length..];
    }
    else if (arg.StartsWith("--copies=", StringComparison.OrdinalIgnoreCase)
        && int.TryParse(arg["--copies=".Length..], out var parsedCopies))
    {
        copies = Math.Max(1, parsedCopies);
    }
    else if (arg.StartsWith("--target=", StringComparison.OrdinalIgnoreCase))
    {
        var value = arg["--target=".Length..].Trim().ToLowerInvariant();
        printTarget = value == "barcode" ? "barcode" : "receipt";
    }
    else if (arg.StartsWith("--barcode=", StringComparison.OrdinalIgnoreCase))
    {
        barcodeValue = arg["--barcode=".Length..];
    }
    else if (arg.StartsWith("--barcode-printer=", StringComparison.OrdinalIgnoreCase))
    {
        barcodePrinter = arg["--barcode-printer=".Length..];
    }
    else if (arg.StartsWith("--barcode-copies=", StringComparison.OrdinalIgnoreCase)
        && int.TryParse(arg["--barcode-copies=".Length..], out var parsedBarcodeCopies))
    {
        barcodeCopies = Math.Max(1, parsedBarcodeCopies);
    }
    else if (arg.StartsWith("--api=", StringComparison.OrdinalIgnoreCase))
    {
        apiBaseUrl = arg["--api=".Length..].TrimEnd('/');
    }
    else if (arg.StartsWith("--direct-print=", StringComparison.OrdinalIgnoreCase))
    {
        var value = arg["--direct-print=".Length..].Trim();
        directPrintEnabled = value.Equals("1", StringComparison.OrdinalIgnoreCase)
            || value.Equals("true", StringComparison.OrdinalIgnoreCase)
            || value.Equals("yes", StringComparison.OrdinalIgnoreCase)
            || value.Equals("on", StringComparison.OrdinalIgnoreCase);
    }
    else if (arg.StartsWith("--barcode-direct-print=", StringComparison.OrdinalIgnoreCase))
    {
        var value = arg["--barcode-direct-print=".Length..].Trim();
        barcodeDirectPrintEnabled = value.Equals("1", StringComparison.OrdinalIgnoreCase)
            || value.Equals("true", StringComparison.OrdinalIgnoreCase)
            || value.Equals("yes", StringComparison.OrdinalIgnoreCase)
            || value.Equals("on", StringComparison.OrdinalIgnoreCase);
    }
}

if (runLayoutTool)
{
    await LayoutTool.RunAsync();
    return;
}

using var http = new HttpClient();

var isBarcode = printTarget == "barcode";
var activePrinter = isBarcode ? barcodePrinter : printer;
var activeCopies = isBarcode ? barcodeCopies : copies;
var activeDirectPrintEnabled = isBarcode ? barcodeDirectPrintEnabled : directPrintEnabled;
Console.WriteLine(isBarcode ? "Building barcode PDF..." : "Building sample receipt PDF...");
var pdfBytes = isBarcode
    ? SampleReceiptPdf.BuildBarcodeBytes(barcodeValue)
    : SampleReceiptPdf.BuildBytes("CS-001", "c# .net/SampleReceiptPdf.cs");

if (!activeDirectPrintEnabled)
{
    await SavePreviewAsync(pdfBytes, "Direct print disabled.", isBarcode);
    return;
}

var pdfBase64 = Convert.ToBase64String(pdfBytes);

var payload = new
{
    printer = activePrinter,
    type = "pdf",
    copies = activeCopies,
    content = pdfBase64
};

Console.WriteLine("Sending to print client...");
try
{
    using var response = await http.PostAsJsonAsync($"{apiBaseUrl}/print", payload);
    var responseBody = await response.Content.ReadAsStringAsync();

    if (!response.IsSuccessStatusCode)
    {
        await SavePreviewAsync(pdfBytes, $"Print client returned HTTP {(int)response.StatusCode}.", isBarcode);
        return;
    }

    Console.WriteLine(string.IsNullOrWhiteSpace(responseBody)
        ? "Print request sent."
        : responseBody);
}
catch (HttpRequestException)
{
    await SavePreviewAsync(pdfBytes, "Print client unavailable.", isBarcode);
}
catch (TaskCanceledException)
{
    await SavePreviewAsync(pdfBytes, "Print client unavailable.", isBarcode);
}

static async Task SavePreviewAsync(byte[] pdfBytes, string reason, bool isBarcode)
{
    var fileName = isBarcode ? "sample-barcode-preview.pdf" : "sample-receipt-preview.pdf";
    var previewPath = Path.Combine(SampleReceiptPdf.FindProjectDirectory(), fileName);
    await File.WriteAllBytesAsync(previewPath, pdfBytes);
    Console.WriteLine($"{reason} PDF saved to {previewPath}");
}
