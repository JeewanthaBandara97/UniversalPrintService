<?php
declare(strict_types=1);

require_once __DIR__ . '/sample_receipt_pdf.php';

$fields = directPrintGetReceiptFields('PHP-001', 'php/layout_tool.php');
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>PHP Receipt Layout Tool</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 32px; background: #f6f8fb; color: #172033; }
        main { max-width: 1120px; margin: 0 auto; background: #fff; border: 1px solid #d8dee9; border-radius: 8px; padding: 24px; }
        .workspace { display: grid; grid-template-columns: minmax(360px, 1fr) 320px; gap: 24px; align-items: start; }
        .preview-wrap { overflow: auto; padding: 16px; border: 1px solid #d8dee9; border-radius: 8px; background: #eef2f7; }
        .receipt-preview { position: relative; width: 324px; height: 396px; margin: 0 auto; background: #fff; border: 1px solid #9aa4b2; box-shadow: 0 8px 24px rgba(16, 24, 40, 0.12); }
        .receipt-field { position: absolute; font-family: Arial, sans-serif; font-weight: 700; white-space: nowrap; cursor: pointer; outline: 1px dashed transparent; padding: 1px 2px; user-select: none; }
        .receipt-field.selected { color: #155eef; background: rgba(21, 94, 239, 0.08); outline-color: #155eef; }
        .controls { border: 1px solid #d8dee9; border-radius: 8px; padding: 16px; }
        label { display: block; margin-top: 16px; font-weight: 700; }
        input, select { width: 100%; box-sizing: border-box; margin-top: 6px; padding: 10px 12px; border: 1px solid #b8c2d1; border-radius: 6px; font: inherit; }
        button { margin-top: 12px; padding: 10px 16px; border: 0; border-radius: 6px; background: #155eef; color: #fff; font-weight: 700; cursor: pointer; }
        .control-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; }
        .nudge-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 8px; }
        .muted { color: #667085; font-size: 13px; }
        @media (max-width: 860px) { .workspace { grid-template-columns: 1fr; } }
    </style>
</head>
<body>
<main>
    <h1>PHP Receipt Layout Tool</h1>
    <div class="workspace">
        <section class="preview-wrap">
            <div id="receiptPreview" class="receipt-preview"></div>
        </section>
        <aside class="controls">
            <label for="fieldSelect">Receipt field</label>
            <select id="fieldSelect"></select>
            <div class="control-grid">
                <div><label for="fieldX">X</label><input id="fieldX" type="number" step="1"></div>
                <div><label for="fieldY">Y</label><input id="fieldY" type="number" step="1"></div>
                <div><label for="fieldSize">Font</label><input id="fieldSize" type="number" step="1" min="4"></div>
                <div><label for="fieldStep">Step</label><input id="fieldStep" type="number" step="1" min="1" value="2"></div>
            </div>
            <div class="nudge-grid">
                <button type="button" data-move="up">Up</button>
                <button type="button" data-move="down">Down</button>
                <button type="button" data-move="left">Left</button>
                <button type="button" data-move="right">Right</button>
                <button type="button" data-move="font-up">A+</button>
                <button type="button" data-move="font-down">A-</button>
            </div>
            <button id="resetLayoutButton" type="button">Reset Layout</button>
            <p id="saveStatus" class="muted">Layout auto-saves to receipt_layout.json.</p>
        </aside>
    </div>
</main>
<script>
    var page = { width: 324, height: 396 };
    var fields = <?php echo json_encode(array_values($fields), JSON_UNESCAPED_SLASHES); ?>;
    var selectedKey = fields.length ? fields[0].key : '';
    var saveTimer = null;
    var receiptPreview = document.getElementById('receiptPreview');
    var fieldSelect = document.getElementById('fieldSelect');
    var fieldX = document.getElementById('fieldX');
    var fieldY = document.getElementById('fieldY');
    var fieldSize = document.getElementById('fieldSize');
    var fieldStep = document.getElementById('fieldStep');
    var saveStatus = document.getElementById('saveStatus');

    function findField(key) {
        return fields.find(function(field) { return field.key === key; }) || null;
    }

    function renderPreview() {
        receiptPreview.innerHTML = '';
        fields.forEach(function(field) {
            var element = document.createElement('div');
            element.className = 'receipt-field' + (field.key === selectedKey ? ' selected' : '');
            element.textContent = field.text;
            element.style.left = field.x + 'px';
            element.style.top = (page.height - field.y - field.size) + 'px';
            element.style.fontSize = field.size + 'px';
            element.addEventListener('click', function() {
                selectedKey = field.key;
                refreshControls();
                renderPreview();
            });
            receiptPreview.appendChild(element);
        });
    }

    function refreshControls() {
        var selected = findField(selectedKey);
        fieldSelect.innerHTML = '';
        fields.forEach(function(field) {
            var option = document.createElement('option');
            option.value = field.key;
            option.textContent = field.label;
            fieldSelect.appendChild(option);
        });
        if (!selected) { return; }
        fieldSelect.value = selected.key;
        fieldX.value = selected.x;
        fieldY.value = selected.y;
        fieldSize.value = selected.size;
    }

    function saveLayout(reset) {
        saveStatus.textContent = reset ? 'Resetting layout...' : 'Saving layout...';
        return fetch('save_layout.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(reset ? { reset: true } : { fields: fields })
        }).then(function(response) {
            return response.json().then(function(body) {
                if (!response.ok || !body.ok) {
                    throw new Error(body.message || 'Save failed.');
                }
                if (reset && Array.isArray(body.fields)) {
                    fields = body.fields;
                    selectedKey = fields.length ? fields[0].key : '';
                    refreshControls();
                    renderPreview();
                }
                saveStatus.textContent = reset ? 'Layout reset.' : 'Layout saved automatically.';
            });
        }).catch(function(error) {
            saveStatus.textContent = error.message || 'Save failed.';
        });
    }

    function queueSave() {
        window.clearTimeout(saveTimer);
        saveTimer = window.setTimeout(function() { saveLayout(false); }, 250);
    }

    function applyInputs() {
        var selected = findField(selectedKey);
        if (!selected) { return; }
        selected.x = parseFloat(fieldX.value || '0') || 0;
        selected.y = parseFloat(fieldY.value || '0') || 0;
        selected.size = Math.max(4, parseFloat(fieldSize.value || '10') || 10);
        renderPreview();
        queueSave();
    }

    function nudge(action) {
        var selected = findField(selectedKey);
        var step = parseFloat(fieldStep.value || '2') || 2;
        if (!selected) { return; }
        if (action === 'up') { selected.y += step; }
        if (action === 'down') { selected.y -= step; }
        if (action === 'left') { selected.x -= step; }
        if (action === 'right') { selected.x += step; }
        if (action === 'font-up') { selected.size += step; }
        if (action === 'font-down') { selected.size = Math.max(4, selected.size - step); }
        refreshControls();
        renderPreview();
        queueSave();
    }

    fieldSelect.addEventListener('change', function() {
        selectedKey = fieldSelect.value;
        refreshControls();
        renderPreview();
    });
    [fieldX, fieldY, fieldSize].forEach(function(input) { input.addEventListener('input', applyInputs); });
    document.querySelectorAll('[data-move]').forEach(function(button) {
        button.addEventListener('click', function() { nudge(button.dataset.move); });
    });
    document.getElementById('resetLayoutButton').addEventListener('click', function() { saveLayout(true); });
    refreshControls();
    renderPreview();
</script>
</body>
</html>

