# HTML Example

Open this through XAMPP, not as a `file://` page:

```text
http://localhost/CASHIER_REPORTS/direct-print-example/html/index.html
```

Use the left **Receipt** panel to print the receipt through `Printer01`. Use the right **Barcode** panel to print the barcode through `Printer02`.

The layout editor is on the same page. Move fields or change font size; changes auto-save in browser `localStorage`.

Receipt and barcode each have their own direct-print checkbox. If direct print is disabled, or the local print client is not running, the page opens the in-page PDF preview modal automatically.
