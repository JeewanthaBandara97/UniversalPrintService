<?php
declare(strict_types=1);

require_once __DIR__ . '/sample_receipt_pdf.php';

header('Content-Type: application/json');

try {
    $body = file_get_contents('php://input');
    $payload = json_decode((string)$body, true);

    if (!is_array($payload)) {
        throw new RuntimeException('Invalid JSON payload.');
    }

    if (($payload['reset'] ?? false) === true) {
        directPrintResetReceiptLayout();
        echo json_encode(array('ok' => true, 'fields' => directPrintGetReceiptFields()));
        exit;
    }

    $fields = $payload['fields'] ?? null;

    if (!is_array($fields)) {
        throw new RuntimeException('Missing fields array.');
    }

    directPrintSaveReceiptLayout($fields);
    echo json_encode(array('ok' => true));
} catch (Throwable $error) {
    http_response_code(400);
    echo json_encode(array('ok' => false, 'message' => $error->getMessage()));
}

