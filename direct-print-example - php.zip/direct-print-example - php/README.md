# PHP Example

Browser:

```text
http://localhost/CASHIER_REPORTS/direct-print-example/php/direct_print_example.php
```

Layout editor:

```text
http://localhost/CASHIER_REPORTS/direct-print-example/php/layout_tool.php
```

CLI:

```powershell
php direct-print-example\php\direct_print_example.php --printer=Printer01 --copies=1
```

Barcode CLI:

```powershell
php direct-print-example\php\direct_print_example.php --target=barcode --barcode=PHP-001 --barcode-printer=Printer02
```

The layout tool auto-saves to `receipt_layout.json`. The print script uses that saved layout when building the sample PDF.

Receipt and barcode each have their own direct-print checkbox on the browser page. Receipt defaults to `Printer01`; barcode defaults to `Printer02`. If direct print is disabled, or the local print client is not running, the page opens the in-page PDF preview modal automatically.

CLI preview without direct print:

```powershell
php direct-print-example\php\direct_print_example.php --direct-print=false
```

Barcode CLI preview without direct print:

```powershell
php direct-print-example\php\direct_print_example.php --target=barcode --barcode-direct-print=false
```
