using System.Net;
using System.Text;
using System.Text.Json;

internal static class LayoutTool
{
    private static readonly JsonSerializerOptions JsonOptions = new()
    {
        PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
        PropertyNameCaseInsensitive = true,
        WriteIndented = true
    };

    public static async Task RunAsync()
    {
        using var listener = new HttpListener();
        listener.Prefixes.Add("http://127.0.0.1:5055/");
        listener.Start();

        Console.WriteLine("C# direct print web example running at http://127.0.0.1:5055/");
        Console.WriteLine("Press Ctrl+C to stop.");

        while (listener.IsListening)
        {
            var context = await listener.GetContextAsync();
            _ = Task.Run(() => HandleAsync(context));
        }
    }

    private static async Task HandleAsync(HttpListenerContext context)
    {
        try
        {
            var path = context.Request.Url?.AbsolutePath ?? "/";

            if (context.Request.HttpMethod == "GET" && path == "/")
            {
                await WriteHtmlAsync(context.Response, BuildHtml());
                return;
            }

            if (context.Request.HttpMethod == "GET" && path == "/layout")
            {
                await WriteJsonAsync(context.Response, new
                {
                    ok = true,
                    fields = SampleReceiptPdf.LoadFields("CS-001", "c# .net/LayoutTool.cs")
                });
                return;
            }

            if (context.Request.HttpMethod == "POST" && path == "/layout")
            {
                var payload = await ReadJsonAsync<SaveLayoutRequest>(context.Request);

                if (payload?.Reset == true)
                {
                    SampleReceiptPdf.ResetLayout();
                    await WriteJsonAsync(context.Response, new
                    {
                        ok = true,
                        fields = SampleReceiptPdf.LoadFields("CS-001", "c# .net/LayoutTool.cs")
                    });
                    return;
                }

                if (payload?.Fields is null)
                {
                    throw new InvalidOperationException("Missing fields array.");
                }

                SampleReceiptPdf.SaveLayout(payload.Fields.Select(field =>
                    new ReceiptLayoutItem(field.Key, field.X, field.Y, field.Size)));
                await WriteJsonAsync(context.Response, new { ok = true });
                return;
            }

            if (context.Request.HttpMethod == "POST" && path == "/print")
            {
                var payload = await ReadJsonAsync<PrintRequest>(context.Request)
                    ?? throw new InvalidOperationException("Invalid print request.");
                await HandlePrintAsync(context.Response, payload);
                return;
            }

            context.Response.StatusCode = 404;
            await WriteTextAsync(context.Response, "Not found", "text/plain");
        }
        catch (Exception error)
        {
            context.Response.StatusCode = 400;
            await WriteJsonAsync(context.Response, new { ok = false, message = error.Message });
        }
    }

    private static async Task HandlePrintAsync(HttpListenerResponse response, PrintRequest request)
    {
        var isBarcode = string.Equals(request.Target, "barcode", StringComparison.OrdinalIgnoreCase);
        var directPrintEnabled = isBarcode ? request.BarcodeDirectPrintEnabled : request.DirectPrintEnabled;
        var printer = isBarcode
            ? (string.IsNullOrWhiteSpace(request.BarcodePrinter) ? "Printer02" : request.BarcodePrinter)
            : (string.IsNullOrWhiteSpace(request.Printer) ? "Printer01" : request.Printer);
        var copies = Math.Max(1, isBarcode ? request.BarcodeCopies : request.Copies);
        var pdfBytes = isBarcode
            ? SampleReceiptPdf.BuildBarcodeBytes(request.BarcodeValue ?? "CS-001")
            : SampleReceiptPdf.BuildBytes("CS-001", "c# .net/LayoutTool.cs");
        var pdfBase64 = Convert.ToBase64String(pdfBytes);

        if (!directPrintEnabled)
        {
            await WriteJsonAsync(response, new
            {
                ok = true,
                preview = true,
                message = isBarcode ? "Barcode direct print disabled." : "Receipt direct print disabled.",
                pdfBase64
            });
            return;
        }

        try
        {
            using var http = new HttpClient { Timeout = TimeSpan.FromSeconds(8) };
            var apiBaseUrl = string.IsNullOrWhiteSpace(request.ApiBaseUrl)
                ? "http://127.0.0.1:5000"
                : request.ApiBaseUrl.TrimEnd('/');
            var body = JsonSerializer.Serialize(new
            {
                printer,
                type = "pdf",
                copies,
                content = pdfBase64
            }, JsonOptions);

            using var content = new StringContent(body, Encoding.UTF8, "application/json");
            using var printResponse = await http.PostAsync(apiBaseUrl + "/print", content);
            var responseBody = await printResponse.Content.ReadAsStringAsync();

            if (!printResponse.IsSuccessStatusCode)
            {
                await WriteJsonAsync(response, new
                {
                    ok = true,
                    preview = true,
                    message = "Print client returned HTTP " + (int)printResponse.StatusCode + ".",
                    pdfBase64
                });
                return;
            }

            await WriteJsonAsync(response, new
            {
                ok = true,
                preview = false,
                message = string.IsNullOrWhiteSpace(responseBody)
                    ? (isBarcode ? "Barcode print request sent." : "Receipt print request sent.")
                    : responseBody
            });
        }
        catch (Exception)
        {
            await WriteJsonAsync(response, new
            {
                ok = true,
                preview = true,
                message = "Print client unavailable.",
                pdfBase64
            });
        }
    }

    private static async Task<T?> ReadJsonAsync<T>(HttpListenerRequest request)
    {
        using var reader = new StreamReader(request.InputStream, request.ContentEncoding);
        var body = await reader.ReadToEndAsync();
        return JsonSerializer.Deserialize<T>(body, JsonOptions);
    }

    private static string BuildHtml()
    {
        return """
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>C# Direct Print Example</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 32px; color: #172033; background: #f6f8fb; }
        main { max-width: 1280px; margin: 0 auto; background: #fff; border: 1px solid #d8dee9; border-radius: 8px; padding: 24px; }
        h1 { margin: 0 0 18px; font-size: 24px; }
        h2 { margin: 0 0 14px; font-size: 18px; }
        label { display: block; margin-top: 16px; font-weight: 700; }
        input, select { width: 100%; box-sizing: border-box; margin-top: 6px; padding: 10px 12px; border: 1px solid #b8c2d1; border-radius: 6px; font: inherit; }
        input[type="checkbox"] { width: auto; margin: 0; }
        button { margin-top: 20px; padding: 10px 16px; border: 0; border-radius: 6px; color: #fff; font-weight: 700; cursor: pointer; }
        button:disabled { background: #8896ab; cursor: wait; }
        .common-settings { margin-bottom: 18px; padding: 14px 16px; border: 1px solid #d8dee9; border-radius: 8px; background: #f8fafc; }
        .common-settings label { margin-top: 0; }
        .print-split { display: grid; grid-template-columns: minmax(0, 1fr) 360px; gap: 24px; align-items: start; }
        .receipt-panel, .barcode-panel { border: 1px solid #d8dee9; border-radius: 8px; padding: 16px; background: #fff; }
        .workspace { display: grid; grid-template-columns: minmax(340px, 1fr) 300px; gap: 16px; align-items: start; }
        .preview-wrap { overflow: auto; padding: 16px; border: 1px solid #d8dee9; border-radius: 8px; background: #eef2f7; }
        .receipt-preview { position: relative; width: 324px; height: 396px; margin: 0 auto; background: #fff; border: 1px solid #9aa4b2; box-shadow: 0 8px 24px rgba(16, 24, 40, 0.12); }
        .receipt-field { position: absolute; font-family: Arial, sans-serif; font-weight: 700; white-space: nowrap; cursor: pointer; outline: 1px dashed transparent; padding: 1px 2px; user-select: none; }
        .receipt-field.selected { color: #155eef; background: rgba(21, 94, 239, 0.08); outline-color: #155eef; }
        .control-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; }
        .nudge-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 8px; }
        .toggle-row { display: flex; align-items: center; gap: 10px; margin-top: 16px; font-weight: 700; }
        .settings-box { margin-top: 16px; padding-top: 14px; border-top: 1px solid #e4e7ec; }
        .button-row { display: grid; grid-template-columns: 1fr; gap: 10px; margin-top: 14px; }
        .button-row button { margin-top: 0; }
        .btn-receipt { background: #155eef; }
        .btn-barcode { background: #0f766e; }
        .btn-reset { background: #475467; }
        .muted { color: #667085; font-size: 13px; }
        .barcode-preview { height: 180px; display: flex; align-items: center; justify-content: center; margin-top: 16px; padding: 16px; border: 1px solid #d8dee9; border-radius: 8px; background: #f8fafc; }
        .barcode-box { width: 260px; padding: 14px; background: #fff; border: 1px solid #cbd5e1; text-align: center; }
        .barcode-bars { height: 78px; display: flex; align-items: stretch; justify-content: center; gap: 1px; }
        .barcode-bar { width: 2px; background: #111827; }
        .barcode-space { width: 2px; background: transparent; }
        .barcode-text { margin-top: 10px; font-weight: 700; letter-spacing: 1px; }
        pre { margin-top: 18px; padding: 12px; background: #101828; color: #e6edf7; border-radius: 6px; white-space: pre-wrap; }
        .pdf-modal { position: fixed; inset: 0; z-index: 1000; display: none; align-items: center; justify-content: center; padding: 24px; background: rgba(16, 24, 40, 0.68); }
        .pdf-modal.open { display: flex; }
        .pdf-dialog { width: min(920px, 96vw); height: min(760px, 92vh); display: flex; flex-direction: column; overflow: hidden; background: #fff; border-radius: 8px; box-shadow: 0 24px 80px rgba(16, 24, 40, 0.35); }
        .pdf-dialog-header { display: flex; align-items: center; justify-content: space-between; gap: 16px; padding: 12px 16px; border-bottom: 1px solid #d8dee9; font-weight: 700; }
        .pdf-close { margin: 0; padding: 8px 12px; background: #344054; }
        .pdf-frame { width: 100%; flex: 1; border: 0; background: #f2f4f7; }
        @media (max-width: 860px) { .print-split, .workspace { grid-template-columns: 1fr; } }
    </style>
</head>
<body>
<main>
    <h1>C# Direct Print Example</h1>
    <div class="common-settings">
        <label for="apiBaseUrl">Print client URL</label>
        <input id="apiBaseUrl" value="http://127.0.0.1:5000">
    </div>
    <div class="print-split">
        <section class="receipt-panel">
            <h2>Receipt</h2>
            <div class="workspace">
                <section class="preview-wrap"><div id="receiptPreview" class="receipt-preview"></div></section>
                <aside>
                    <label for="fieldSelect">Receipt field</label><select id="fieldSelect"></select>
                    <div class="control-grid">
                        <div><label for="fieldX">X</label><input id="fieldX" type="number" step="1"></div>
                        <div><label for="fieldY">Y</label><input id="fieldY" type="number" step="1"></div>
                        <div><label for="fieldSize">Font</label><input id="fieldSize" type="number" step="1" min="4"></div>
                        <div><label for="fieldStep">Step</label><input id="fieldStep" type="number" step="1" min="1" value="2"></div>
                    </div>
                    <div class="nudge-grid">
                        <button type="button" class="btn-reset" data-move="up">Up</button><button type="button" class="btn-reset" data-move="down">Down</button><button type="button" class="btn-reset" data-move="left">Left</button>
                        <button type="button" class="btn-reset" data-move="right">Right</button><button type="button" class="btn-reset" data-move="font-up">A+</button><button type="button" class="btn-reset" data-move="font-down">A-</button>
                    </div>
                    <div class="settings-box">
                        <label for="printer">Receipt printer slot</label><input id="printer" value="Printer01">
                        <label for="copies">Receipt copies</label><input id="copies" type="number" min="1" value="1">
                        <label class="toggle-row" for="directPrintEnabled"><input id="directPrintEnabled" type="checkbox" checked>Enable direct print</label>
                    </div>
                    <div class="button-row">
                        <button id="printButton" class="btn-receipt" type="button">Print / Preview Receipt</button>
                        <button id="resetLayoutButton" class="btn-reset" type="button">Reset Layout</button>
                    </div>
                    <p id="saveStatus" class="muted">Layout auto-saves to receipt-layout.json.</p>
                </aside>
            </div>
        </section>
        <aside class="barcode-panel">
            <h2>Barcode</h2>
            <label for="barcodeValue">Barcode value</label><input id="barcodeValue" value="CS-001">
            <label for="barcodePrinter">Barcode printer slot</label><input id="barcodePrinter" value="Printer02">
            <label for="barcodeCopies">Copies</label><input id="barcodeCopies" type="number" min="1" value="1">
            <label class="toggle-row" for="barcodeDirectPrintEnabled"><input id="barcodeDirectPrintEnabled" type="checkbox" checked>Enable barcode direct print</label>
            <div id="barcodePreview" class="barcode-preview"></div>
            <button id="barcodePrintButton" class="btn-barcode" type="button">Print / Preview Barcode</button>
        </aside>
    </div>
    <pre id="status">Ready.</pre>
</main>
<div id="pdfModal" class="pdf-modal" role="dialog" aria-modal="true" aria-labelledby="pdfModalTitle">
    <div class="pdf-dialog">
        <div class="pdf-dialog-header"><span id="pdfModalTitle">Preview</span><button id="pdfCloseButton" class="pdf-close" type="button">Close</button></div>
        <iframe id="pdfFrame" class="pdf-frame" title="PDF preview"></iframe>
    </div>
</div>
<script>
var page = { width: 324, height: 396 };
var fields = [];
var selectedKey = '';
var saveTimer = null;
var receiptPreview = document.getElementById('receiptPreview');
var fieldSelect = document.getElementById('fieldSelect');
var fieldX = document.getElementById('fieldX');
var fieldY = document.getElementById('fieldY');
var fieldSize = document.getElementById('fieldSize');
var fieldStep = document.getElementById('fieldStep');
var saveStatus = document.getElementById('saveStatus');
var statusBox = document.getElementById('status');
var pdfModal = document.getElementById('pdfModal');
var pdfFrame = document.getElementById('pdfFrame');
var currentPreviewUrl = '';
var barcodeValue = document.getElementById('barcodeValue');
var barcodePreview = document.getElementById('barcodePreview');
function setStatus(message) { statusBox.textContent = message; }
function findField(key) { return fields.find(function(field) { return field.key === key; }) || null; }
function barcodeBits(value) {
    var text = String(value || 'CS-001').toUpperCase();
    var bits = [];
    for (var i = 0; i < text.length; i++) {
        var code = text.charCodeAt(i);
        for (var bit = 7; bit >= 0; bit--) { bits.push(((code >> bit) & 1) === 1); }
        bits.push(false, true, false);
    }
    return bits;
}
function renderBarcodePreview() {
    var value = barcodeValue.value || 'CS-001';
    var bars = barcodeBits(value).map(function(isBar) { return '<span class="' + (isBar ? 'barcode-bar' : 'barcode-space') + '"></span>'; }).join('');
    barcodePreview.innerHTML = '<div class="barcode-box"><div class="barcode-bars">' + bars + '</div><div class="barcode-text">' + value.toUpperCase().replace(/[<>&]/g, '') + '</div></div>';
}
function renderPreview() {
    receiptPreview.innerHTML = '';
    fields.forEach(function(field) {
        var element = document.createElement('div');
        element.className = 'receipt-field' + (field.key === selectedKey ? ' selected' : '');
        element.textContent = field.text;
        element.style.left = field.x + 'px';
        element.style.top = (page.height - field.y - field.size) + 'px';
        element.style.fontSize = field.size + 'px';
        element.addEventListener('click', function() { selectedKey = field.key; refreshControls(); renderPreview(); });
        receiptPreview.appendChild(element);
    });
}
function refreshControls() {
    var selected = findField(selectedKey);
    fieldSelect.innerHTML = '';
    fields.forEach(function(field) {
        var option = document.createElement('option');
        option.value = field.key;
        option.textContent = field.label;
        fieldSelect.appendChild(option);
    });
    if (!selected) { return; }
    fieldSelect.value = selected.key;
    fieldX.value = selected.x;
    fieldY.value = selected.y;
    fieldSize.value = selected.size;
}
function saveLayout(reset) {
    saveStatus.textContent = reset ? 'Resetting layout...' : 'Saving layout...';
    return fetch('/layout', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(reset ? { reset: true } : { fields: fields })
    }).then(function(response) {
        return response.json().then(function(body) {
            if (!response.ok || !body.ok) { throw new Error(body.message || 'Save failed.'); }
            if (reset && Array.isArray(body.fields)) {
                fields = body.fields;
                selectedKey = fields.length ? fields[0].key : '';
                refreshControls();
                renderPreview();
            }
            saveStatus.textContent = reset ? 'Layout reset.' : 'Layout saved automatically.';
        });
    }).catch(function(error) { saveStatus.textContent = error.message || 'Save failed.'; });
}
function queueSave() { window.clearTimeout(saveTimer); saveTimer = window.setTimeout(function() { saveLayout(false); }, 250); }
function applyInputs() {
    var selected = findField(selectedKey);
    if (!selected) { return; }
    selected.x = parseFloat(fieldX.value || '0') || 0;
    selected.y = parseFloat(fieldY.value || '0') || 0;
    selected.size = Math.max(4, parseFloat(fieldSize.value || '10') || 10);
    renderPreview();
    queueSave();
}
function nudge(action) {
    var selected = findField(selectedKey);
    var step = parseFloat(fieldStep.value || '2') || 2;
    if (!selected) { return; }
    if (action === 'up') { selected.y += step; }
    if (action === 'down') { selected.y -= step; }
    if (action === 'left') { selected.x -= step; }
    if (action === 'right') { selected.x += step; }
    if (action === 'font-up') { selected.size += step; }
    if (action === 'font-down') { selected.size = Math.max(4, selected.size - step); }
    refreshControls();
    renderPreview();
    queueSave();
}
function previewPdf(base64) {
    var binary = atob(base64);
    var bytes = new Uint8Array(binary.length);
    for (var i = 0; i < binary.length; i++) { bytes[i] = binary.charCodeAt(i); }
    var url = URL.createObjectURL(new Blob([bytes], { type: 'application/pdf' }));
    if (currentPreviewUrl) { URL.revokeObjectURL(currentPreviewUrl); }
    currentPreviewUrl = url;
    pdfFrame.src = url;
    pdfModal.classList.add('open');
}
function sendPrint(target) {
    var isBarcode = target === 'barcode';
    var button = document.getElementById(isBarcode ? 'barcodePrintButton' : 'printButton');
    button.disabled = true;
    setStatus(isBarcode ? 'Sending barcode...' : 'Sending receipt...');
    fetch('/print', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            target: target,
            apiBaseUrl: document.getElementById('apiBaseUrl').value,
            printer: document.getElementById('printer').value,
            copies: parseInt(document.getElementById('copies').value, 10) || 1,
            directPrintEnabled: document.getElementById('directPrintEnabled').checked,
            barcodeValue: document.getElementById('barcodeValue').value,
            barcodePrinter: document.getElementById('barcodePrinter').value,
            barcodeCopies: parseInt(document.getElementById('barcodeCopies').value, 10) || 1,
            barcodeDirectPrintEnabled: document.getElementById('barcodeDirectPrintEnabled').checked
        })
    }).then(function(response) {
        return response.json().then(function(body) {
            if (!response.ok || !body.ok) { throw new Error(body.message || 'Print failed.'); }
            if (body.preview && body.pdfBase64) { previewPdf(body.pdfBase64); }
            setStatus(body.message || 'Done.');
        });
    }).catch(function(error) {
        setStatus(error.message || 'Print failed.');
    }).finally(function() {
        button.disabled = false;
    });
}
fieldSelect.addEventListener('change', function() { selectedKey = fieldSelect.value; refreshControls(); renderPreview(); });
[fieldX, fieldY, fieldSize].forEach(function(input) { input.addEventListener('input', applyInputs); });
document.querySelectorAll('[data-move]').forEach(function(button) { button.addEventListener('click', function() { nudge(button.dataset.move); }); });
document.getElementById('resetLayoutButton').addEventListener('click', function() { saveLayout(true); });
document.getElementById('printButton').addEventListener('click', function() { sendPrint('receipt'); });
document.getElementById('barcodePrintButton').addEventListener('click', function() { sendPrint('barcode'); });
barcodeValue.addEventListener('input', renderBarcodePreview);
document.getElementById('pdfCloseButton').addEventListener('click', function() {
    pdfModal.classList.remove('open');
    pdfFrame.removeAttribute('src');
    if (currentPreviewUrl) { URL.revokeObjectURL(currentPreviewUrl); currentPreviewUrl = ''; }
});
pdfModal.addEventListener('click', function(event) { if (event.target === pdfModal) { document.getElementById('pdfCloseButton').click(); } });
fetch('/layout').then(function(response) { return response.json(); }).then(function(body) {
    fields = body.fields || [];
    selectedKey = fields.length ? fields[0].key : '';
    refreshControls();
    renderPreview();
});
renderBarcodePreview();
</script>
</body>
</html>
""";
    }

    private static async Task WriteHtmlAsync(HttpListenerResponse response, string value)
    {
        await WriteTextAsync(response, value, "text/html; charset=utf-8");
    }

    private static async Task WriteJsonAsync(HttpListenerResponse response, object value)
    {
        await WriteTextAsync(response, JsonSerializer.Serialize(value, JsonOptions), "application/json; charset=utf-8");
    }

    private static async Task WriteTextAsync(HttpListenerResponse response, string value, string contentType)
    {
        var bytes = Encoding.UTF8.GetBytes(value);
        response.ContentType = contentType;
        response.ContentLength64 = bytes.Length;
        await response.OutputStream.WriteAsync(bytes);
        response.OutputStream.Close();
    }

    private sealed record SaveLayoutRequest(bool Reset, List<ReceiptField>? Fields);

    private sealed record PrintRequest(
        string? Target,
        string? ApiBaseUrl,
        string? Printer,
        int Copies,
        bool DirectPrintEnabled,
        string? BarcodeValue,
        string? BarcodePrinter,
        int BarcodeCopies,
        bool BarcodeDirectPrintEnabled);
}
