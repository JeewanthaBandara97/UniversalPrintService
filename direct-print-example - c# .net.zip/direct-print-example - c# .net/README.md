# C# .NET Example

Run:

```powershell
dotnet run --project "direct-print-example\c# .net\DirectPrintExample.csproj" -- --printer=Printer01 --copies=1
```

Barcode:

```powershell
dotnet run --project "direct-print-example\c# .net\DirectPrintExample.csproj" -- --target=barcode --barcode=CS-001 --barcode-printer=Printer02
```

Browser UI like the HTML example:

```powershell
dotnet run --project "direct-print-example\c# .net\DirectPrintExample.csproj" -- --web
```

Then open:

```text
http://127.0.0.1:5055/
```

The web UI has the common print-client URL at top, receipt on the left, barcode on the right, separate direct-print toggles, colored print buttons, and in-page PDF preview fallback. Layout changes auto-save to `receipt-layout.json`.

Preview/save the PDF without direct print:

```powershell
dotnet run --project "direct-print-example\c# .net\DirectPrintExample.csproj" -- --direct-print=false
```

If direct print is enabled but the local print client is not running, the command saves `sample-receipt-preview.pdf` automatically.

Barcode direct print can be disabled separately:

```powershell
dotnet run --project "direct-print-example\c# .net\DirectPrintExample.csproj" -- --target=barcode --barcode-direct-print=false
```
