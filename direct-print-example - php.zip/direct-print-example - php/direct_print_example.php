<?php
declare(strict_types=1);

require_once __DIR__ . '/sample_receipt_pdf.php';

$apiBaseUrl = 'http://127.0.0.1:5000';
$printer = 'Printer01';
$copies = 1;
$barcodeValue = 'PHP-001';
$barcodePrinter = 'Printer02';
$barcodeCopies = 1;
$directPrintEnabled = true;
$barcodeDirectPrintEnabled = true;
$printTarget = 'receipt';
$previewPdfBase64 = '';
$previewReason = '';

if (PHP_SAPI === 'cli') {
    foreach ($argv as $arg) {
        if (strpos($arg, '--printer=') === 0) {
            $printer = substr($arg, 10);
        } elseif (strpos($arg, '--copies=') === 0) {
            $copies = max(1, (int)substr($arg, 9));
        } elseif (strpos($arg, '--api=') === 0) {
            $apiBaseUrl = rtrim(substr($arg, 6), '/');
        } elseif (strpos($arg, '--direct-print=') === 0) {
            $value = strtolower(trim(substr($arg, 15)));
            $directPrintEnabled = in_array($value, array('1', 'true', 'yes', 'on'), true);
        } elseif (strpos($arg, '--barcode=') === 0) {
            $barcodeValue = substr($arg, 10);
        } elseif (strpos($arg, '--target=') === 0) {
            $value = strtolower(trim(substr($arg, 9)));
            $printTarget = $value === 'barcode' ? 'barcode' : 'receipt';
        } elseif (strpos($arg, '--barcode-printer=') === 0) {
            $barcodePrinter = substr($arg, 18);
        } elseif (strpos($arg, '--barcode-copies=') === 0) {
            $barcodeCopies = max(1, (int)substr($arg, 17));
        } elseif (strpos($arg, '--barcode-direct-print=') === 0) {
            $value = strtolower(trim(substr($arg, 23)));
            $barcodeDirectPrintEnabled = in_array($value, array('1', 'true', 'yes', 'on'), true);
        }
    }
} elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $apiBaseUrl = rtrim((string)($_POST['api_base_url'] ?? $apiBaseUrl), '/');
    $printer = (string)($_POST['printer'] ?? $printer);
    $copies = max(1, (int)($_POST['copies'] ?? $copies));
    $barcodeValue = (string)($_POST['barcode_value'] ?? $barcodeValue);
    $barcodePrinter = (string)($_POST['barcode_printer'] ?? $barcodePrinter);
    $barcodeCopies = max(1, (int)($_POST['barcode_copies'] ?? $barcodeCopies));
    if (array_key_exists('direct_print_enabled', $_POST)) {
        $directPrintEnabled = $_POST['direct_print_enabled'] === '1';
    }
    if (array_key_exists('barcode_direct_print_enabled', $_POST)) {
        $barcodeDirectPrintEnabled = $_POST['barcode_direct_print_enabled'] === '1';
    }
    $printTarget = (string)($_POST['print_target'] ?? 'receipt');
}

function directPrintPostJson(string $url, array $payload): array
{
    $json = json_encode($payload);

    if ($json === false) {
        throw new RuntimeException('Could not encode print payload.');
    }

    $ch = curl_init($url);

    curl_setopt_array($ch, array(
        CURLOPT_POST => true,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_CONNECTTIMEOUT => 5,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_HTTPHEADER => array('Content-Type: application/json'),
        CURLOPT_POSTFIELDS => $json,
    ));

    $body = curl_exec($ch);
    $statusCode = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
    $error = curl_error($ch);
    curl_close($ch);

    if ($body === false || $statusCode < 200 || $statusCode >= 300) {
        throw new RuntimeException('Direct print failed. HTTP ' . $statusCode . ($error ? ' - ' . $error : '') . "\n" . (string)$body);
    }

    return array($statusCode, (string)$body);
}

function directPrintPreviewResult(string $pdfBinary, string $reason, bool $isBarcode = false): array
{
    if (PHP_SAPI === 'cli') {
        $previewPath = __DIR__ . ($isBarcode ? '/sample_barcode_preview.pdf' : '/sample_receipt_preview.pdf');
        file_put_contents($previewPath, $pdfBinary);
        echo $reason . ' PDF saved to ' . $previewPath . PHP_EOL;
        exit;
    }

    return array(
        'reason' => $reason,
        'base64' => base64_encode($pdfBinary),
    );
}

if (PHP_SAPI !== 'cli' && $_SERVER['REQUEST_METHOD'] !== 'POST') {
    $message = 'Ready.';
} else {
    try {
    $isBarcode = $printTarget === 'barcode';
    $activePrinter = $isBarcode ? $barcodePrinter : $printer;
    $activeCopies = $isBarcode ? $barcodeCopies : $copies;
    $activeDirectPrintEnabled = $isBarcode ? $barcodeDirectPrintEnabled : $directPrintEnabled;
    $pdfBinary = $isBarcode
        ? directPrintBuildBarcodePdf($barcodeValue)
        : directPrintBuildSampleReceiptPdf('PHP-001', 'php/sample_receipt_pdf.php');

    if (!$activeDirectPrintEnabled) {
        $preview = directPrintPreviewResult($pdfBinary, 'Direct print disabled.', $isBarcode);
        $previewPdfBase64 = $preview['base64'];
        $previewReason = $preview['reason'];
        $message = $previewReason . ' PDF preview opened.';
    } else {
        try {
            list($statusCode, $responseBody) = directPrintPostJson(rtrim($apiBaseUrl, '/') . '/print', array(
                'printer' => $activePrinter,
                'type' => 'pdf',
                'copies' => $activeCopies,
                'content' => base64_encode($pdfBinary),
            ));
            $message = ($isBarcode ? 'Barcode' : 'Receipt') . " print request sent. HTTP {$statusCode}\n{$responseBody}";
        } catch (Throwable $printError) {
            $preview = directPrintPreviewResult($pdfBinary, 'Print client unavailable.', $isBarcode);
            $previewPdfBase64 = $preview['base64'];
            $previewReason = $preview['reason'];
            $message = $previewReason . ' PDF preview opened instead.';
        }
    }
    } catch (Throwable $error) {
        http_response_code(500);
        $message = $error->getMessage();
    }
}

if (PHP_SAPI === 'cli') {
    echo $message . PHP_EOL;
    exit;
}
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Direct Print PHP Example</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 32px; background: #f6f8fb; color: #172033; }
        main { max-width: 760px; margin: 0 auto; background: #fff; border: 1px solid #d8dee9; border-radius: 8px; padding: 24px; }
        label { display: block; margin-top: 16px; font-weight: 700; }
        input { width: 100%; box-sizing: border-box; margin-top: 6px; padding: 10px 12px; border: 1px solid #b8c2d1; border-radius: 6px; font: inherit; }
        input[type="checkbox"] { width: auto; margin: 0; }
        .toggle-row { display: flex; align-items: center; gap: 10px; margin-top: 16px; font-weight: 700; }
        button { margin-top: 20px; padding: 10px 16px; border: 0; border-radius: 6px; background: #155eef; color: #fff; font-weight: 700; cursor: pointer; }
        .btn-receipt { background: #155eef; }
        .btn-barcode { background: #0f766e; }
        pre { margin-top: 18px; padding: 12px; background: #101828; color: #e6edf7; border-radius: 6px; white-space: pre-wrap; }
        .pdf-modal { position: fixed; inset: 0; z-index: 1000; display: none; align-items: center; justify-content: center; padding: 24px; background: rgba(16, 24, 40, 0.68); }
        .pdf-modal.open { display: flex; }
        .pdf-dialog { width: min(920px, 96vw); height: min(760px, 92vh); display: flex; flex-direction: column; overflow: hidden; background: #fff; border-radius: 8px; box-shadow: 0 24px 80px rgba(16, 24, 40, 0.35); }
        .pdf-dialog-header { display: flex; align-items: center; justify-content: space-between; gap: 16px; padding: 12px 16px; border-bottom: 1px solid #d8dee9; font-weight: 700; }
        .pdf-close { margin: 0; padding: 8px 12px; background: #344054; }
        .pdf-frame { width: 100%; flex: 1; border: 0; background: #f2f4f7; }
        .print-split { display: grid; grid-template-columns: minmax(0, 1fr) 360px; gap: 24px; align-items: start; }
        .common-settings { display: grid; grid-template-columns: minmax(260px, 1fr); gap: 10px; margin-bottom: 18px; padding: 14px 16px; border: 1px solid #d8dee9; border-radius: 8px; background: #f8fafc; }
        .common-settings label { margin-top: 0; }
        .panel { border: 1px solid #d8dee9; border-radius: 8px; padding: 16px; }
        .barcode-preview { height: 180px; display: flex; align-items: center; justify-content: center; margin-top: 16px; padding: 16px; border: 1px solid #d8dee9; border-radius: 8px; background: #f8fafc; }
        .barcode-box { width: 260px; padding: 14px; background: #fff; border: 1px solid #cbd5e1; text-align: center; }
        .barcode-bars { height: 78px; display: flex; align-items: stretch; justify-content: center; gap: 1px; }
        .barcode-bar { width: 2px; background: #111827; }
        .barcode-space { width: 2px; background: transparent; }
        .barcode-text { margin-top: 10px; font-weight: 700; letter-spacing: 1px; }
        @media (max-width: 860px) { .print-split { grid-template-columns: 1fr; } }
    </style>
</head>
<body>
<main>
<h1>Direct Print PHP Example</h1>
<p><a href="layout_tool.php">Edit receipt layout</a></p>
<div class="common-settings">
    <label for="api_base_url_common">Print client URL</label>
    <input id="api_base_url_common" form="receiptForm" name="api_base_url" value="<?php echo htmlspecialchars($apiBaseUrl, ENT_QUOTES, 'UTF-8'); ?>">
</div>
<div class="print-split">
<section class="panel">
<h2>Receipt</h2>
<form id="receiptForm" method="post">
    <input type="hidden" name="print_target" value="receipt">
    <label for="printer">Printer slot</label>
    <input id="printer" name="printer" value="<?php echo htmlspecialchars($printer, ENT_QUOTES, 'UTF-8'); ?>">

    <label for="copies">Copies</label>
    <input id="copies" name="copies" type="number" min="1" value="<?php echo htmlspecialchars((string)$copies, ENT_QUOTES, 'UTF-8'); ?>">

    <label class="toggle-row" for="direct_print_enabled">
        <input id="direct_print_enabled" name="direct_print_enabled" type="checkbox" value="1" <?php echo $directPrintEnabled ? 'checked' : ''; ?>>
        Enable direct print
    </label>

    <button class="btn-receipt" type="submit">Print / Preview Receipt</button>
</form>
</section>
<aside class="panel">
<h2>Barcode</h2>
<form id="barcodeForm" method="post">
    <input type="hidden" name="print_target" value="barcode">
    <input id="barcode_api_base_url" type="hidden" name="api_base_url" value="<?php echo htmlspecialchars($apiBaseUrl, ENT_QUOTES, 'UTF-8'); ?>">
    <input type="hidden" name="printer" value="<?php echo htmlspecialchars($printer, ENT_QUOTES, 'UTF-8'); ?>">
    <input type="hidden" name="copies" value="<?php echo htmlspecialchars((string)$copies, ENT_QUOTES, 'UTF-8'); ?>">
    <input type="hidden" name="direct_print_enabled" value="<?php echo $directPrintEnabled ? '1' : '0'; ?>">

    <label for="barcode_value">Barcode value</label>
    <input id="barcode_value" name="barcode_value" value="<?php echo htmlspecialchars($barcodeValue, ENT_QUOTES, 'UTF-8'); ?>">

    <label for="barcode_printer">Barcode printer slot</label>
    <input id="barcode_printer" name="barcode_printer" value="<?php echo htmlspecialchars($barcodePrinter, ENT_QUOTES, 'UTF-8'); ?>">

    <label for="barcode_copies">Copies</label>
    <input id="barcode_copies" name="barcode_copies" type="number" min="1" value="<?php echo htmlspecialchars((string)$barcodeCopies, ENT_QUOTES, 'UTF-8'); ?>">

    <label class="toggle-row" for="barcode_direct_print_enabled">
        <input id="barcode_direct_print_enabled" name="barcode_direct_print_enabled" type="checkbox" value="1" <?php echo $barcodeDirectPrintEnabled ? 'checked' : ''; ?>>
        Enable barcode direct print
    </label>

    <div id="barcodePreview" class="barcode-preview"></div>
    <button class="btn-barcode" type="submit">Print / Preview Barcode</button>
</form>
</aside>
</div>
<pre><?php echo htmlspecialchars($message, ENT_QUOTES, 'UTF-8'); ?></pre>
</main>
<div id="pdfModal" class="pdf-modal<?php echo $previewPdfBase64 !== '' ? ' open' : ''; ?>" role="dialog" aria-modal="true" aria-labelledby="pdfModalTitle">
    <div class="pdf-dialog">
        <div class="pdf-dialog-header">
            <span id="pdfModalTitle"><?php echo htmlspecialchars($previewReason !== '' ? $previewReason : 'Receipt Preview', ENT_QUOTES, 'UTF-8'); ?></span>
            <button id="pdfCloseButton" class="pdf-close" type="button">Close</button>
        </div>
        <iframe id="pdfFrame" class="pdf-frame" title="Receipt PDF preview" <?php echo $previewPdfBase64 !== '' ? 'src="data:application/pdf;base64,' . htmlspecialchars($previewPdfBase64, ENT_QUOTES, 'UTF-8') . '"' : ''; ?>></iframe>
    </div>
</div>
<script>
    var pdfModal = document.getElementById('pdfModal');
    var pdfFrame = document.getElementById('pdfFrame');
    var pdfCloseButton = document.getElementById('pdfCloseButton');

    pdfCloseButton.addEventListener('click', function() {
        pdfModal.classList.remove('open');
        pdfFrame.removeAttribute('src');
    });

    pdfModal.addEventListener('click', function(event) {
        if (event.target === pdfModal) {
            pdfCloseButton.click();
        }
    });

    function barcodeBits(value) {
        var text = String(value || 'PHP-001').toUpperCase();
        var bits = [];
        for (var i = 0; i < text.length; i++) {
            var code = text.charCodeAt(i);
            for (var bit = 7; bit >= 0; bit--) {
                bits.push(((code >> bit) & 1) === 1);
            }
            bits.push(false, true, false);
        }
        return bits;
    }

    function renderBarcodePreview() {
        var input = document.getElementById('barcode_value');
        var preview = document.getElementById('barcodePreview');
        var value = input.value || 'PHP-001';
        var bars = barcodeBits(value).map(function(isBar) {
            return '<span class="' + (isBar ? 'barcode-bar' : 'barcode-space') + '"></span>';
        }).join('');
        preview.innerHTML = '<div class="barcode-box"><div class="barcode-bars">' + bars
            + '</div><div class="barcode-text">' + value.toUpperCase().replace(/[<>&]/g, '') + '</div></div>';
    }

    document.getElementById('barcode_value').addEventListener('input', renderBarcodePreview);
    document.getElementById('barcodeForm').addEventListener('submit', function() {
        document.getElementById('barcode_api_base_url').value = document.getElementById('api_base_url_common').value;
    });
    renderBarcodePreview();
</script>
</body>
</html>
